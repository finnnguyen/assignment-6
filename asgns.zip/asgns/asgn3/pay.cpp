#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include "person.h"
using namespace std;

// function prototypes
void readData(vector<Person> &employees);
void getCompanies(vector<string> &companyNames, vector<Person> &employees);
void printHighestPaid(vector<Person> &employees);
void separateAndSave(vector<string> &companyNames, vector<Person> &employees);

// main function
int main()
{
	// list of employees
	vector<Person> employees;
	// list of company names
	vector<string> companyNames;

	// read employee data
	readData(employees);
	// read company names
	getCompanies(companyNames, employees);
	// print highest paid employee
	printHighestPaid(employees);
	// write the payroll information for each company
	separateAndSave(companyNames, employees);

	return 0;
}

// Read the data from "input.txt" and store it in the employees vector.
void readData(vector<Person> &employees)
{
	// input file stream
	ifstream fin;
	// Person object
	Person p;

	// open "input.txt" file
	fin.open("input.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'input.txt'" << endl;
		return;
	}

	// read employee data
	while (fin >> p)
	{
		// add employee to vector
		employees.push_back(p);
	}

	// close file
	fin.close();
}

// Retrieves the company names from employees and adds them to companyNames
void getCompanies(vector<string> &companyNames, vector<Person> &employees)
{
	for (size_t i = 0; i < employees.size(); i++)
	{
		size_t j;

		for (j = 0; j < companyNames.size(); j++)
		{
			if (companyNames[j] == employees[i].getCompanyName())
				break;
		}

		if (j == companyNames.size())
			companyNames.push_back(employees[i].getCompanyName());
	}
}

// Output the full name, employee ID, company name and total pay of the person
// who was paid the highest amount.
void printHighestPaid(vector<Person> &employees)
{
	// position of highest paid employee
	size_t i = 0;

	// if vector is empty then do nothing
	if (employees.size() == 0)
		return;

	// find the position of highest paid employee
	for (size_t j = 1; j < employees.size(); j++)
	{
		if (employees[j].totalPay() > employees[i].totalPay())
			i = j;
	}

	// format floating output to 2 digits after decimal
	cout << fixed << showpoint << setprecision(2);

	// print full name, employee ID, company name and total pay
	cout << "Highest paid: " << employees[i].fullName() << endl;
	cout << "Employee ID: " << employees[i].getEmployeeId() << endl;
	cout << "Employer: " << employees[i].getCompanyName() << endl;
	cout << "Total Pay: $" << employees[i].totalPay() << endl;
}

// Write the payroll information to multiple text files - one for each company.
// Each file should be named after the company (e.g. Boeing.txt) and contain
// only the employees from that company. Within the file, the data should be
// formatted by selecting reasonable column widths for output. The float output
// should be truncated to 2 decimal places. The output should also have the
// total pay for each company.
void separateAndSave(vector<string> &companyNames, vector<Person> &employees)
{
	// for each company names
	for (size_t i = 0; i < companyNames.size(); i++)
	{
		// prepare output file name
		string filename = companyNames[i] + ".txt";
		// output file stream
		ofstream fout;
		// total pay of company
		float total = 0.0;

		// open file
		fout.open(filename.c_str());

		// if could not open file
		if (!fout)
		{
			// print error
			cout << "Error: could not open file '" << filename << "'" << endl;
			continue;
		}

		for (size_t j = 0; j < employees.size(); j++)
		{
			if (employees[j].getCompanyName() == companyNames[i])
			{
				// write employee to file
				fout << employees[j] << endl;
				// add total pay to total pay of company
				total += employees[j].totalPay();
			}
		}

		// set floating output to 2 digits after decimal
		fout << fixed << showpoint << setprecision(2);
		// write total pay
		fout << "Total $" << total << endl;

		// close file
		fout.close();
	}
}
