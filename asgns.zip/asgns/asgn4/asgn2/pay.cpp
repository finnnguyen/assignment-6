#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include "person.h"
using namespace std;

// function prototypes
void readData(vector<Person> &employees);
void writeData(vector<Person> &employees);

// main function
int main()
{
	// define vector to hold employees
	vector<Person> employees;

	// read data
	readData(employees);
	// write data
	writeData(employees);

	return 0;
}

// Read the employees data from "input.txt" and store it into vector
void readData(vector<Person> &employees)
{
	// input file stream
	ifstream fin;
	// first name, last name
	string first, last;
	// hours worked and pay rate
	float hours, rate;

	// open "input.txt" file
	fin.open("input.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'input.txt'" << endl;
		return;
	}

	// read employee data
	while (fin >> first >> last >> hours >> rate)
	{
		// push new employee into vector
		employees.emplace_back(Person(first, last, rate, hours));
	}

	// close file
	fin.close();
}

// Write the results to "output.txt"
void writeData(vector<Person> &employees)
{
	// output file stream
	ofstream fout;

	// open "output.txt" file
	fout.open("output.txt");

	// if could not open file
	if (!fout)
	{
		// print error
		cout << "Error: could not open file 'output.txt'" << endl;
		return;
	}

	// set floating output to 2 digits after decimal
	fout << fixed << showpoint << setprecision(2);

	// write full name and total pay to the file
	for (size_t i = 0; i < employees.size(); i++)
	{
		fout << employees[i].fullName() << " " 
			<< employees[i].totalPay() << endl;
	}

	// close file
	fout.close();
}
