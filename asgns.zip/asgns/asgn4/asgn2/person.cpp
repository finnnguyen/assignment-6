#include "person.h"

// default constructor
Person::Person()
{
}

// constructor
Person::Person(string fName, string lName, float rate, float hours)
{
	firstName = fName;
	lastName = lName;
	payRate = rate;
	hoursWorked = hours;
}

// set last name
void Person::setLastName(string lName)
{
	lastName = lName;
}

// get last name
string Person::getLastName()
{
	return lastName;
}

// set first name
void Person::setFirstName(string fName)
{
	firstName = fName;
}

// get first name
string Person::getFirstName()
{
	return firstName;
}

// set pay rate
void Person::setPayRate(float rate)
{
	payRate = rate;
}

// get pay rate
float Person::getPayRate()
{
	return payRate;
}

// set hours worked
void Person::setHoursWorked(float hours)
{
	hoursWorked = hours;
}

// get hours worked
float Person::getHoursWorked()
{
	return hoursWorked;
}

// return total pay
float Person::totalPay()
{
	return hoursWorked*payRate;
}

// return full name
string Person::fullName()
{
	return firstName + " " + lastName;
}
