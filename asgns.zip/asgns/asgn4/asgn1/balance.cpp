#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;

// define PERSON structure to store customer information
struct PERSON
{
	char Name[20];
	float Balance;
};

// function prototypes
void printmenu();
PERSON * readData(int & N);
void Display(const PERSON *a, int N);
void FindRichest(const PERSON *a, int N);
void Deposit(PERSON *a, int N, const char custName[], float amount);
void NewCopy(const char filename[], const PERSON *a, int N);

// main function
int main()
{
	// input file stream
	ifstream fin;
	// dynamic array to hold customer records
	PERSON *a;
	// number of records
	int N;
	// first name
	char first[10];
	// last name
	char last[10];
	// first name string
	string firstStr;
	// last name string 
	string lastStr;
	// customer name
	char custName[20];
	// amount to deposit
	float amount;
	// menu choice
	int choice;

	// read all records
	a = readData(N);

	do
	{
		// print menu
		printmenu();
		// read menu choice
		cin >> choice;
		
		// process menu choice
		switch (choice)
		{
		case 1:
			// display all records
			Display(a, N);
			break;
		case 2:
			// ask the user to enter customer name
			cout << "Enter name: ";
			cin >> firstStr >> lastStr;

			// only consider 9 characters from first and last name
			if (firstStr.length() > 9)
				strcpy(first, firstStr.substr(0, 9).c_str());
			else
				strcpy(first, firstStr.c_str());

			if (lastStr.length() > 9)
				strcpy(last, lastStr.substr(0, 9).c_str());
			else
				strcpy(last, lastStr.c_str());

			// prepare full name
			strcpy(custName, first);
			strcat(custName, " ");
			strcat(custName, last);

			// ask how much to desposit
			cout << "Amount: ";
			cin >> amount;

			// deposit money
			Deposit(a, N, custName, amount);
			break;
		case 3:
			// display name of customer with maximum balance
			FindRichest(a, N);
			break;
		case 4:
			// copy array a in the same file
			NewCopy("data.txt", a, N);
			break;
		case 5:
			// copy array a in the same file
			NewCopy("data.txt", a, N);
			break;
		default:
			cout << "Invalid entry" << endl;
			break;
		}

		cout << endl;
	} while (choice != 5);

	// deallocate array
	if (a != NULL)
		delete[] a;

	return 0;
}

// Print menu
void printmenu()
{
	cout << "Please enter a choice:" << endl;
	cout << "1. Display records"<< endl;
	cout << "2. Deposit funds"<< endl;
	cout << "3. Find Highest Balance" << endl;
	cout << "4. Update records" << endl;
	cout << "5. Exit the program" << endl;
}

// Read all records and return dynamic array of type PERSON
PERSON * readData(int & N)
{
	// input file stream
	ifstream fin;
	// dynamic array to hold customer records
	PERSON *a;
	// first name
	char first[10];
	// last name
	char last[10];
	// balance
	float balance;
	// first name string
	string firstStr;
	// last name string
	string lastStr;
	// position
	int i;

	// initialize number of records
	N = 0;

	// open file
	fin.open("data.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'data.txt'" << endl;
		// return NULL
		return NULL;
	}

	// count the number of records
	while (fin >> firstStr >> lastStr >> balance)
		N++;

	// close file
	fin.close();
	fin.clear();

	// open file again
	fin.open("data.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'data.txt'" << endl;
		// return NULL
		return NULL;
	}

	// create an array to hold all N records
	a = new PERSON[N];

	// read N records
	for (i = 0; i < N; i++)
	{
		// read first name, last name and balance
		fin >> firstStr >> lastStr >> a[i].Balance;

		// only consider 9 characters from first and last name
		if (firstStr.length() > 9)
			strcpy(first, firstStr.substr(0, 9).c_str());
		else
			strcpy(first, firstStr.c_str());

		if (lastStr.length() > 9)
			strcpy(last, lastStr.substr(0, 9).c_str());
		else
			strcpy(last, lastStr.c_str());

		// prepare full name
		strcpy(a[i].Name, first);
		strcat(a[i].Name, " ");
		strcat(a[i].Name, last);
	}

	// close file
	fin.close();

	// return dynamic array
	return a;
}

// Display all records in array a
void Display(const PERSON *a, int N)
{
	// format floating output to 2 digits after decimal
	cout << fixed << showpoint << setprecision(2);

	for (int i = 0; i < N; i++)
	{
		// display name and balance
		cout << left << setw(20) << a[i].Name << right << setw(10) << a[i].Balance << endl;
	}
}

// Find the customer with maximum balance
void FindRichest(const PERSON *a, int N)
{
	int i = 0;
	
	if (N == 0) return;

	for (int j = 1; j < N; j++)
		if (a[j].Balance > a[i].Balance)
			i = j;

	cout << "Highest balance: " << a[i].Name << endl;
}

// Deposit money in customer account using customer name
void Deposit(PERSON *a, int N, const char custName[], float amount)
{
	if (amount <= 0)
	{
		// print error
		cout << "Error: amount must be positive" << endl;
		return;
	}

	// go through each customer
	for (int i = 0; i < N; i++)
	{
		// if customer name matched
		if (strcmp(a[i].Name, custName) == 0)
		{
			// add amount to balance
			a[i].Balance += amount;
			// display new balance
			cout << "New balance: " << a[i].Balance << endl;
			return;
		}
	}

	// print error
	cout << "Record not found" << endl;
}

// copy array a in the same file
void NewCopy(const char filename[], const PERSON *a, int N)
{
	// output file stream
	ofstream fout;

	// open file
	fout.open(filename);

	// if could not open file
	if (!fout)
	{
		// print error
		cout << "Error: could not open file '" << filename << "'" << endl;
		return;
	}

	// format floating output to 2 digits after decimal
	fout << fixed << showpoint << setprecision(2);

	// write customer name and balance to the file
	for (int i = 0; i < N; i++)
		fout << a[i].Name << " " << a[i].Balance << endl;

	// close file
	fout.close();

	cout << "File Updated..." << endl;
}
