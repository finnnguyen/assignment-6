#include <iomanip>
#include "person.h"

// default constructor
Person::Person()
{
}

// constructor
Person::Person(string fName, string lName, int id, string coName, float hours, float rate)
{
	firstName = fName;
	lastName = lName;
	employeeID = id;
	companyName = coName;
	hoursWorked = hours;
	payRate = rate;
}

// set first name
void Person::setFirstName(string fName)
{
	firstName = fName;
}

// get first name
string Person::getFirstName()
{
	return firstName;
}

// set last name
void Person::setLastName(string lName)
{
	lastName = lName;
}

// get last name
string Person::getLastName()
{
	return lastName;
}

// set employee ID
void Person::setEmployeeId(int id)
{
	employeeID = id;
}

// get employee ID
int Person::getEmployeeId()
{
	return employeeID;
}

// set company name
void Person::setCompanyName(string coName)
{
	companyName = coName;
}

// get company name
string Person::getCompanyName()
{
	return companyName;
}

// set pay rate
void Person::setPayRate(float rate)
{
	payRate = rate;
}

// get pay rate
float Person::getPayRate()
{
	return payRate;
}

// set hours worked
void Person::setHoursWorked(float hours)
{
	hoursWorked = hours;
}

// get hours worked
float Person::getHoursWorked()
{
	return hoursWorked;
}

// return total pay
float Person::totalPay()
{
	float total = hoursWorked*payRate;
	
	total = (int)(total*100)/100.0;

	return total;
}

// return full name
string Person::fullName()
{
	return firstName + " " + lastName;
}

// overload insertion operator
ostream& operator<<(ostream& os, Person& p)
{
	os << fixed << showpoint << setprecision(2);
	os << left << setw(10) << p.firstName << " "
		<< setw(10) << p.lastName << " "
		<< right << setw(5) << p.employeeID << " "
		<< left << setw(10) << p.companyName << " $"
		<< p.totalPay();
	return os;
}

// overload extraction operator
istream& operator>>(istream& is, Person& p)
{
	is >> p.firstName >> p.lastName >> p.employeeID >> p.companyName 
		>> p.hoursWorked >> p.payRate;
	return is;
}

