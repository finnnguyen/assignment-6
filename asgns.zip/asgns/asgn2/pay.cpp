#include <iostream>
#include <iomanip>
#include <fstream>
#include "person.h"
using namespace std;

// function prototypes
void readData(Person a[], int &n);
void writeData(Person a[], int n);

// main function
int main()
{
	// define an array to hold 20 employees
	Person a[20];
	// number of employees
	int n;

	// read data
	readData(a, n);
	// write data
	writeData(a, n);

	return 0;
}

// Read the employees data from "input.txt" and store it in the array
void readData(Person a[], int &n)
{
	// input file stream
	ifstream fin;
	// first name, last name
	string first, last;
	// hours worked and pay rate
	float hours, rate;

	// set number of employees to 0
	n = 0;

	// open "input.txt" file
	fin.open("input.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'input.txt'" << endl;
		return;
	}

	// read employee data
	while (fin >> first >> last >> hours >> rate)
	{
		// set employee data
		a[n].setFirstName(first);
		a[n].setLastName(last);
		a[n].setHoursWorked(hours);
		a[n].setPayRate(rate);
		// increment number of employees
		n++;
	}

	// close file
	fin.close();
}

// Write the results to "output.txt"
void writeData(Person a[], int n)
{
	// output file stream
	ofstream fout;

	// open "output.txt" file
	fout.open("output.txt");

	// if could not open file
	if (!fout)
	{
		// print error
		cout << "Error: could not open file 'output.txt'" << endl;
		return;
	}

	// set floating output to 2 digits after decimal
	fout << fixed << showpoint << setprecision(2);

	// write full name and total pay to the file
	for (int i = 0; i < n; i++)
	{
		fout << a[i].fullName() << " " << a[i].totalPay() << endl;
	}

	// close file
	fout.close();
}
