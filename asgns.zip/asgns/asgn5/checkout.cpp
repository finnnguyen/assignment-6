// Name
// Section #
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "person.h"
#include "book.h"
using namespace std;

// function prototypes
void printMenu();
void readBooks(vector<Book *> & books);
int readPersons(vector<Person *> & cardholders);
void readRentals(vector<Book *> & books, vector<Person *> & cardholders);
Book * searchBook(vector<Book *> books, int id);
Person * searchPerson(vector<Person *> cardholders, int id);
Person * searchPerson(vector<Person *> cardholders, string firstName, string lastName);
void writePersons(vector<Person *> & cardholders);
void writeRentals(vector<Book *> & books);

int main()
{
	// list of books
	vector<Book *> books;
	// list of persons
	vector<Person *> cardholders;
	// menu choice
	int choice;
	// next card ID
	int nextID;
	// first and last name
	string firstName, lastName;
	// card id
	int cardID;
	// book id
	int bookID;
	// Person pointer
	Person * personPtr;
	// Book pointer
	Book * bookPtr;
	// choice to deactivate card
	char confirm;
	// number of rentals
	int count;

	// read books
	readBooks(books);
	// read card holders
	nextID = readPersons(cardholders);
	// read rentals
	readRentals(books, cardholders);

	do
	{
		// If you use cin anywhere, don't forget that you have to handle the <ENTER> key that 
		// the user pressed when entering a menu option. This is still in the input stream.
		printMenu();
		cin >> choice;
		
		switch (choice)
		{
		case 1:
			// ask the user to enter card ID
			cout << "Please enter the card ID: ";
			cin >> cardID;

			// search person
			personPtr = searchPerson(cardholders, cardID);

			// if person is not found or card is not active then print message
			if (personPtr == nullptr || !personPtr->isActive())
				cout << "Card ID not found" << endl;
			else
			{
				// print cardholder name
				cout << "Cardholder: " << personPtr->fullName() << endl;
				
				// ask the user to enter book ID to check out
				cout << "Please enter the book ID: ";
				cin >> bookID;

				// search book
				bookPtr = searchBook(books, bookID);

				// if book is not found then print message
				if (bookPtr == nullptr)
					cout << "Book ID not found" << endl;
				else
				{
					// if book is already checked out then print message
					if (bookPtr->getPersonPtr() != nullptr)
						cout << "Book already checked out" << endl;
					else
					{
						// print book title
						cout << "Title: " << bookPtr->getTitle() << endl;
						// checkout book
						bookPtr->setPersonPtr(personPtr);
						cout << "Rental Completed" << endl;
					}
				}
			}
			break;
		case 2:
			// ask the user to enter book ID
			cout << "Please enter the book ID to return: ";
			cin >> bookID;

			// search book
			bookPtr = searchBook(books, bookID);

			// if book is not found then print message
			if (bookPtr == nullptr)
				cout << "Book ID not found" << endl;
			else
			{
				// print book title
				cout << "Title: " << bookPtr->getTitle() << endl;

				// if book is not checked out then print message
				if (bookPtr->getPersonPtr() == nullptr)
					cout << "Book is not checked out" << endl;
				else
				{
					// return book
					bookPtr->setPersonPtr(nullptr);
					cout << "Return Completed" << endl;
				}
			}
			break;
		case 3:
			// number of available books
			count = 0;

			for (size_t i = 0; i < books.size(); i++)
			{
				if (books[i]->getPersonPtr() == nullptr)
				{
					cout << "Book ID: " << books[i]->getId() << endl;
					cout << "Title: " << books[i]->getTitle() << endl;
					cout << "Author: " << books[i]->getAuthor() << endl;
					cout << "Category: " << books[i]->getCategory() << endl;
					cout << endl;
					count++;
				}
			}

			// if no available books
			if (count == 0)
				cout << "No available books" << endl;
			break;
		case 4:
			// number of rentals
			count = 0;

			for (size_t i = 0; i < books.size(); i++)
			{
				personPtr = books[i]->getPersonPtr();

				if (personPtr != nullptr)
				{
					cout << "Book ID: " << books[i]->getId() << endl;
					cout << "Title: " << books[i]->getTitle() << endl;
					cout << "Author: " << books[i]->getAuthor() << endl;
					cout << "Cardholder: " << personPtr->fullName() << endl;
					cout << "Card ID: " << personPtr->getId() << endl;
					cout << endl;
					count++;
				}
			}

			// if no rentals
			if (count == 0)
				cout << "No outstanding rentals" << endl;
			break;
		case 5:
			// ask the user to enter card ID
			cout << "Please enter the card ID: ";
			cin >> cardID;

			// search person
			personPtr = searchPerson(cardholders, cardID);

			// if no person found or card ID is not active then print message
			if (personPtr == nullptr || !personPtr->isActive())
				cout << "Card ID not found" << endl;
			else
			{
				// print card holder name
				cout << "Cardholder: " << personPtr->fullName() << endl;

				// count number of rentals
				count = 0;

				for (size_t i = 0; i < books.size(); i++)
				{
					if (books[i]->getPersonPtr() == personPtr)
					{
						cout << endl;
						cout << "Book ID: " << books[i]->getId() << endl;
						cout << "Title: " << books[i]->getTitle() << endl;
						cout << "Author: " << books[i]->getAuthor() << endl;
						count++;
					}
				}

				// if no books checked out then print message
				if (count == 0)
					cout << "No books currently checked out" << endl;
			}
			break;
		case 6:
			// ask the user enter first and last name
			cout << "Please enter the first name: ";
			cin >> firstName;
			cout << "Please enter the last name: ";
			cin >> lastName;

			// search person
			personPtr = searchPerson(cardholders, firstName, lastName);

			// if person is found
			if (personPtr != nullptr)
			{
				// reactivate card
				personPtr->setActive(true);
			}
			else
			{
				// create a Person and insert into cardholders vector
				personPtr = new Person(nextID, true, firstName, lastName);
				cardholders.push_back(personPtr);

				// increment next ID
				nextID++;
			}

			// print card id and full name
			cout << "Card ID " << personPtr->getId() << " active" << endl;
			cout << "Cardholder: " << personPtr->fullName() << endl;
			break;
		case 7:
			// ask the user to enter card ID
			cout << "Please enter the card ID: ";
			cin >> cardID;
			
			// search person
			personPtr = searchPerson(cardholders, cardID);

			// if no person found then print message
			if (personPtr == nullptr)
				cout << "Card ID not found" << endl;
			else
			{
				// print card holder name
				cout << "Cardholder: " << personPtr->fullName() << endl;

				// if card is already inactive then print message
				if (!personPtr->isActive())
					cout << "Card ID is already inactive" << endl;
				else
				{
					// ask for confirmation
					cout << "Are you sure you want to deactivate card (y/n)? ";
					cin >> confirm;

					// if confirmed
					if (confirm == 'y' || confirm == 'Y')
					{
						// return books taken by this cardholder
						for (size_t i = 0; i < books.size(); i++)
						{
							if (books[i]->getPersonPtr() == personPtr)
							{
								books[i]->setPersonPtr(nullptr);
							}
						}

						// deactivate the card ID
						personPtr->setActive(false);
						cout << "Card ID deactivated" << endl;
					}
				}
			}
			break;
		case 8:
			// Must update records in files here before exiting the program
			writePersons(cardholders);
			writeRentals(books);
			break;
		default:
			cout << "Invalid entry" << endl;
			break;
		}

		cout << endl;
	} while (choice != 8);

	// deallocate memory
	for (size_t i = 0; i < books.size(); i++)
		delete books[i];

	for (size_t i = 0; i < cardholders.size(); i++)
		delete cardholders[i];

	return 0;
}

void printMenu() {
	cout << "----------Library Book Rental System----------" << endl;
	cout << "1.  Book checkout" << endl;
	cout << "2.  Book return" << endl;
	cout << "3.  View all available books" << endl;
	cout << "4.  View all outstanding rentals" << endl;
	cout << "5.  View outstanding rentals for a cardholder" << endl;
	cout << "6.  Open new library card" << endl;
	cout << "7.  Close library card" << endl;
	cout << "8.  Exit system" << endl;
	cout << "Please enter a choice: ";
}

// Read books from "books.txt"
void readBooks(vector<Book *> & books) {
	// input file stream
	ifstream fin;
	// book ID
	int bookID;
	// title, author, category
	string title, author, category;
	// line to ignore
	string line;

	// open file
	fin.open("books.txt");

	// if could not open file
	if (!fin)
	{
		// print error message
		cout << "Error: could not open file 'books.txt'" << endl;
		return;
	}

	// read books
	while (fin >> bookID)
	{
		getline(fin, line);
		getline(fin, title);
		getline(fin, author);
		getline(fin, category);

		// create new book and add to vector
		books.push_back(new Book(bookID, title, author, category));
	}

	// close file
	fin.close();
}

// Read card holders from "persons.txt"
// Return the largest card ID + 1
int readPersons(vector<Person *> & cardholders) {
	// input file stream
	ifstream fin;
	// card ID
	int cardID;
	// active
	bool active;
	// first name and last name
	string firstName, lastName;
	// largest card ID
	int largestCardID = -1;

	// open file
	fin.open("persons.txt");

	// if could not open file
	if (!fin)
	{
		// print error message
		cout << "Error: could not open file 'persons.txt'" << endl;
		return 0;
	}

	// read card holders
	while (fin >> cardID >> active >> firstName >> lastName)
	{
		// update largest card ID
		if (cardholders.size() == 0 || cardID > largestCardID)
			largestCardID = cardID;

		// create new person and add to vector
		cardholders.push_back(new Person(cardID, active, firstName, lastName));
	}

	// close file
	fin.close();

	return largestCardID + 1;
}

// Read rentals from "rentals.txt"
void readRentals(vector<Book *> & books, vector<Person *> & cardholders) {
	// input file stream
	ifstream fin;
	// book ID and card ID
	int bookID, cardID;

	// open file
	fin.open("rentals.txt");

	// if could not open file
	if (!fin)
	{
		// print error message
		cout << "Error: could not open file 'rentals.txt'" << endl;
		return;
	}

	// read rentals
	while (fin >> bookID >> cardID)
	{
		// search book
		Book * bookPtr = searchBook(books, bookID);
		// search person
		Person * personPtr = searchPerson(cardholders, cardID);

		// link book with person
		bookPtr->setPersonPtr(personPtr);
	}

	// close file
	fin.close();
}

// Search book of given book id
Book * searchBook(vector<Book *> books, int id) {
	for (size_t i = 0; i < books.size(); i++)
		if (books[i]->getId() == id)
			return books[i];

	return nullptr;
}

// Search person of given card id
Person * searchPerson(vector<Person *> cardholders, int id) {
	for (size_t i = 0; i < cardholders.size(); i++)
		if (cardholders[i]->getId() == id)
			return cardholders[i];

	return nullptr;
}

// Search person by first name and last name
Person * searchPerson(vector<Person *> cardholders, string firstName, string lastName) {
	for (size_t i = 0; i < cardholders.size(); i++)
		if (cardholders[i]->getFirstName() == firstName &&
			cardholders[i]->getLastName() == lastName)
			return cardholders[i];

	return nullptr;
}

// Write cardholders to "persons.txt"
void writePersons(vector<Person *> & cardholders) {
	// output file stream
	ofstream fout;

	// open file
	fout.open("persons.txt");

	// if could not open file
	if (!fout)
	{
		// print error message
		cout << "Error: could not open file 'persons.txt'" << endl;
		return;
	}

	// write person information
	for (size_t i = 0; i < cardholders.size(); i++)
	{
		Person *p = cardholders[i];

		fout << p->getId() << " " << p->isActive() << " " << p->fullName() << endl;
	}

	// close file
	fout.close();
}

// Write rentals to "rentals.txt"
void writeRentals(vector<Book *> & books) {
	// output file stream
	ofstream fout;

	// open file
	fout.open("rentals.txt");

	// if could not open file
	if (!fout)
	{
		// print error message
		cout << "Error: could not open file 'rentals.txt'" << endl;
		return;
	}

	for (size_t i = 0; i < books.size(); i++)
	{
		Book *b = books[i];
		Person *p = b->getPersonPtr();

		// if book is rented by person
		if (p != nullptr)
		{
			// write book id and card id
			fout << b->getId() << " " << p->getId() << endl;
		}
	}

	// close file
	fout.close();
}
