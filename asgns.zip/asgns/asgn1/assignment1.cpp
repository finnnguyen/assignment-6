#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;

// define PERSON structure to store customer information
struct PERSON
{
	char Name[20];
	float Balance;
};

// function prototypes
void Display(const PERSON *a, int N);
int FindRichest(const PERSON *a, int N);
void Deposit(const char CustName[], PERSON *a, int N);
void NewCopy(const char filename[], const PERSON *a, int N);

// main function
int main()
{
	// input file stream
	ifstream fin;
	// dynamic array to hold customer records
	PERSON *a;
	// number of records
	int N;
	// first name
	char first[20];
	// last name
	char last[20];
	// customer name
	char CustName[20];
	// balance
	float balance;
	// position
	int i;

	// open file
	fin.open("data.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'data.txt'" << endl;
		// terminate program
		return 1;
	}

	// count the number of records
	N = 0;
	while (fin >> first >> last >> balance)
		N++;

	// close file
	fin.close();
	fin.clear();

	// open file again
	fin.open("data.txt");

	// if could not open file
	if (!fin)
	{
		// print error
		cout << "Error: could not open file 'data.txt'" << endl;
		// terminate program
		return 1;
	}

	// create an array to hold all N records
	a = new PERSON[N];

	// read N records
	for (i = 0; i < N; i++)
	{
		// read first name, last name and balance
		fin >> first >> last >> a[i].Balance;

		// prepare full name
		strcpy(a[i].Name, first);
		strcat(a[i].Name, " ");
		strcat(a[i].Name, last);
	}

	// close file
	fin.close();

	// display all records
	Display(a, N);

	// display name of customer with maximum balance
	i = FindRichest(a, N);
	cout << endl;
	cout << "The customer with maximum balance is " << a[i].Name << endl;

	// ask the user to enter customer name
	cout << endl;
	cout << "Enter your full name to deposit money: ";
	cin >> first >> last;
	// prepare full name
	strcpy(CustName, first);
	strcat(CustName, " ");
	strcat(CustName, last);
	// deposit money
	Deposit(CustName, a, N);

	// copy array a in the same file
	NewCopy("data.txt", a, N);

	// deallocate array
	delete[] a;

	return 0;
}

// Display all records in array a
void Display(const PERSON *a, int N)
{
	// display column headings
	cout << left << setw(20) << "Name" << right << setw(10) << "Balance" << endl;
	cout << "-----------------------------------------------" << endl;

	// format floating output to 2 digits after decimal
	cout << fixed << showpoint << setprecision(2);

	for (int i = 0; i < N; i++)
	{
		// display name and balance
		cout << left << setw(20) << a[i].Name << right << setw(10) << a[i].Balance << endl;
	}
}

// return the position of customer with maximum balance
int FindRichest(const PERSON *a, int N)
{
	int maximum = 0;

	for (int i = 1; i < N; i++)
		if (a[i].Balance > a[maximum].Balance)
			maximum = i;

	return maximum;
}

// Deposit money in customer account using customer name
void Deposit(const char CustName[], PERSON *a, int N)
{
	// go through each customer
	for (int i = 0; i < N; i++)
	{
		// if customer name matched
		if (strcmp(a[i].Name, CustName) == 0)
		{
			// amount to deposit
			float amount;

			// ask how much to desposit
			cout << CustName << ", how much would you like to deposit? ";
			cin >> amount;

			// if amount is positive
			if (amount > 0)
			{
				// add amount to balance
				a[i].Balance += amount;

				// display new balance
				cout << "Now your new balance is " << a[i].Balance << endl;
			}
			// otherwise
			else
			{
				// print error
				cout << "Error: amount must be positive" << endl;
			}

			return;
		}
	}

	// print error
	cout << "Error: no such customer" << endl;
}

// copy array a in the same file
void NewCopy(const char filename[], const PERSON *a, int N)
{
	// output file stream
	ofstream fout;

	// open file
	fout.open(filename);

	// if could not open file
	if (!fout)
	{
		// print error
		cout << "Error: could not open file '" << filename << "'" << endl;
		return;
	}

	// format floating output to 2 digits after decimal
	fout << fixed << showpoint << setprecision(2);

	// write customer name and balance to the file
	for (int i = 0; i < N; i++)
		fout << a[i].Name << " " << a[i].Balance << endl;

	// close file
	fout.close();
}
